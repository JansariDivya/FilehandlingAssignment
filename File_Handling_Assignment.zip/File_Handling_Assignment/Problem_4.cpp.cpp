/* Problem :- C++ program to find number of words that ends with s in the file
			"out.txt" file contains :- "the sammaes is the eaod the fine"  */
#include<iostream>
#include<fstream>
#include<cstring>
#include<string>
using namespace std;



int main()
{
 char a[80];
int count=0,i=0,flag=0;
 ifstream ifile("out.txt");
 while(!ifile.eof())
 {
   ifile>>a;

	int len = strlen(a);
   
	//function to check
         try
		{
			if(a[len-1]== 's')
			throw 'a';	
		}
	catch(char c)
		{
			 count++;
		}
	  
 }
 cout<<endl<<"Number of words that ends with s in  out.txt file: "<<count<<endl;
return 0;
}

