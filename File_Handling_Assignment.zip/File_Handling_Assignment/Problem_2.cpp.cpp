/* Problem :- C++ program to find number of words that contains a in the file
			"out.txt" file contains :- "the sammaes is the eaod the fine"  */

#include<iostream>
#include<fstream>
#include<cstring>
#include<string>
using namespace std;

int main()
{
 char a[80];
 int count=0,i=0,flag=0;
 ifstream ifile("out.txt");
 while(!ifile.eof())
 {
   ifile>>a;
	int len = strlen(a);

		//function to check word contains a
		for(i=0;i<len;i++)
		{
			try
				{			
					if(a[i]=='a')
					throw 1;
				}
	
			catch(int x)
				{
					
					count++;
					break;
					
				}
		

		}
		
	  
 }
 cout<<endl<<"Number of words in out.txt that contains a are:- "<<count<<endl;
return 0;
}

