/* Problem :- C++ program to find number of time word 'the' in the file
			"out.txt" file contains :- "the sammes is the gaod the fine"  */

#include <iostream>
#include <cstring>
#include <fstream>

using namespace std;
int main()
{


 char a[80];
 int count=0;

 ifstream ifile("out.txt");

 while(!ifile.eof())
 {
	  ifile>>a;
	  try
		{
	  		if((strcmp(a,"the")==0))
			throw 2;
		}
	  catch(int x)
		{
		  	count++;
		}
 }

 cout<<endl<<"Number of time 'the' in the file called out.txt file: "<<count<<endl;
return 0;
}


