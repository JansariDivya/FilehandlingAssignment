/*Problem :- Write a Cpp program that shows the menu : -
              1) Enter the Student DEtails
              2) Find Student */

#include<fstream>
#include<iostream>
#include<string.h>
#include<stdlib.h>
using namespace std;

class Student
{
	private:
	int id;
	char name[20];
	char branch[20];
	char location[20];

	public:
	Student()
	{
		id = 0;
		strcpy(location,"no location");
		strcpy(name,"no name");
		strcpy(branch,"no branch");
		
		
        }

	void getStudentData()
	{
		cout<<endl<<"Enter the id,name,branch,location of the student"<<endl;
		cin>>id;
		cin>>name;
		cin>>branch;
		cin>>location;
		
	}
	
	void showStudentData()
	{
		
		cout<<endl<<id<<"  "<<name<<"   "<<branch<<"  ";
		cout<<location;
	}

	int storeStudent();
	void viewAllStudents();
	void searchStudent(int);
};//end of Class Student


//Function to Search Student from File
void Student::searchStudent(int id1)
{
	int counter=0;
	ifstream fin;
	fin.open("file4.dat",ios::in|ios::binary);
	try
	{		
		if(!fin)
		throw 0;
		else
		{
			fin.read((char*)this,sizeof(*this));
			while(!fin.eof())
			{
				try
					{
					   if(id1==id)
					   throw 1;
					}
				catch(int x)
					{
						cout<<endl<<"Found Student Record!!!!!!"<<endl;
						cout<<endl<<"--------------------------------"<<endl;
						cout<<endl<<"Following are Student details:- "<<endl;
						cout<<endl<<"--------------------------------"<<endl;
						cout<<endl<<"id"<<"  "<<"name"<<"   "<<"branch"<<"   "<<"location"<<endl;
						showStudentData();
						counter++;
					}
				fin.read((char*)this,sizeof(*this));
			}
			
			try
			{
				if(counter==0)
				throw counter;
			}
			catch(int a)
			{
				cout<<endl<<"Student not found"<<endl;
			}

			fin.close();
		}
	}
	catch(int x)
	{
	cout<<endl<<"File not found";
	}
	
	
}

//Function to Display all Students in File
void Student::viewAllStudents()
	{
		ifstream fin;
		fin.open("file4.dat",ios::in|ios::binary);
		try
			{		
				if(!fin)
				throw 'a';
				else
				{
					fin.read((char*)this,sizeof(*this));
					while(!fin.eof())
					{
						
						showStudentData();
						fin.read((char*)this,sizeof(*this));
					}
				}
			}
		catch(char c)
			{
				cout<<endl<<"File not found";
			}
		fin.close();	
	}

//Function to Save Student Record in the File.
int Student::storeStudent()
	{
		if(id==0)
		{
			cout<<"Student data not intialized";
			return (0);
		}
		else
		{
			ofstream fout;
			fout.open("file4.dat",ios::app|ios::binary);
			fout.write((char*)this,sizeof(*this));
			fout.close();
			return(1);
		}	
	}

int menu()
	{
		int choice;
		cout<<endl<<endl<<"----------------------------------"<<endl;
		cout<<endl<<"Student Management"<<endl;
		cout<<endl<<"--------------------------------"<<endl;
		cout<<endl<<"Enter 1 for Enter Student Details";
		cout<<endl<<"Enter 2 for Find Student";
		cout<<endl<<"Enter 3 for Exit";
		cout<<endl<<endl<<"Enter your choice"<<endl;
		cin>>choice;
		return(choice);		
	}

//DRiver Program
int main()
{
	Student s1;
	while(1)
	{
		switch(menu())
			{
				case 1:
					s1.getStudentData();
					s1.storeStudent();
					cout<<endl<<"--------------------------------"<<endl;
					cout<<endl<<"Total Records in file1.dat file"<<endl;
					cout<<endl<<"--------------------------------"<<endl;
					cout<<endl<<"id"<<"  "<<"name"<<"   "<<"branch"<<"   "<<"location"<<endl;
					s1.viewAllStudents();
					cout<<endl;
					cout<<endl<<"Student Record Inserted"<<endl;
					break;
				case 2:
					cout<<endl<<"Enter the id of book to search"<<endl;
					int id;
					cin>>id;
					s1.searchStudent(id);
					break;
				case 3:
					cout<<endl<<"Thankyou for using an application"<<endl;
					cout<<endl<<"Press any key to exit"<<endl;
					exit(0);
				default:
					cout<<endl<<"Invalid Choice"<<endl;
			}	

	}
return 0;
}
